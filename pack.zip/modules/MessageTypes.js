var job = {
    start: "job.start",
    stop: "job.stop",
    started: "job.started",
    completed: "job.completed",
    getStatus: "job.getStatus",
};

export default { job };
